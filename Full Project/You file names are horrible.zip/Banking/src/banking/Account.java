package banking;

import java.text.DecimalFormat;
import java.util.ArrayList;

public class Account {

    protected static int counter = 1;
    private int accountNumber;
    protected Client owner;
    protected String type;
    protected double balance;
    protected ArrayList<Transaction> transactions;
    DecimalFormat df = new DecimalFormat("#,###,##0.00");

    public Account() {
    }
    
    
    public Account(Client owner, String type) {
        this.transactions = new ArrayList<>();
        this.accountNumber = counter;
        this.owner = owner;
        this.type = type;
        this.balance = 0;
        counter++;
    }

    public double deposit(double d) {

        Transaction transaction = new Transaction("deposit", d);
        transactions.add(transaction);
        this.balance = this.balance + d;
        return this.balance;        
    }

    public void displayAllTransactions() {

        transactions.forEach((i) -> {
            System.out.println(i);
        });
    }

    public String displayBalanceCorrectly(){ // Marius: this gives us the balance in the form of 0.00$ rather than 0.0$
        return df.format(this.balance);
    }
    
    @Override
    public String toString() { //Daniel

        String accountInfo = "\u001B[34m" + this.type + "(" + this.accountNumber + "): " + this.displayBalanceCorrectly() + "$" + "\u001B[0m";
        return accountInfo;

    }

    public double withdrawal(double w) {

        Transaction transaction = new Transaction("withdrawal", w);              
        this.transactions.add(transaction);
        this.balance = this.balance - w;
        return this.balance;

    }

    public int getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(int accountNumber) {
        this.accountNumber = accountNumber;
    }

    public int getCounter() {
        return counter;
    }

    public void setCounter(int counter) {
        this.counter = counter;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public Client getOwner() {
        return owner;
    }

    public void setOwner(Client owner) {
        this.owner = owner;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public ArrayList<Transaction> getTransactions() {
        return this.transactions;

    }

    public void setTransactions(ArrayList<Transaction> transactions) {
        this.transactions = transactions;
    }

}
