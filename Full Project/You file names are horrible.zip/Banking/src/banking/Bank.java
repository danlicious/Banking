package banking;

import java.util.ArrayList;

public class Bank implements IBank {


    private static final String bankNumber = "123456789";
    private static final String address = "821 Sainte Croix Ave";
    private static ArrayList<Client> clientList = new ArrayList<>();
    private static final UserInputManager uim = new UserInputManager();

    @Override //Farhan
    public void addClient(Client newClient) {

        clientList.add(newClient.getId() - 1, newClient);

    }

    @Override
    public void displayClientAccounts(int clientId) {
        
          Client client = getClient(clientId);
          client.displayAccounts();
    }

    @Override //Daniel
    public void displayClientList() {

        System.out.println("\nList of current clients:\n");
        for (int i = 0; i < clientList.size(); i++) {
            System.out.println(clientList.get(i).toString());
        }

    }

    @Override//Daniel
    public Client getClient(int id) {
        return clientList.get(id - 1);
    }

    @Override
    public Account getClientAccount(int clientId, int accountNumber) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public static String getBankNumber() {
        return bankNumber;
    }

    public static String getAddress() {
        return address;
    }

    public static ArrayList<Client> getClientList() {
        return clientList;
    }

    public static void setClientList(ArrayList<Client> clientList) {
        Bank.clientList = clientList;
    }
    public boolean listAccountTransactions() {//Daniel  //Marius

        if (getClientList().size() > 0) {
            Client client = getClient(UserInputManager.retrieveClientId());
            if (client.getAccountList().size() > 0) {
                        client.displayAccounts();                      
                        int accNum = UserInputManager.retrieveAccountNumber();
                        Account acc = client.getAccount(accNum);
                        
                        if(acc == null){
                            listAccountTransactions();
                        }else{                        
                        System.out.println("Displaying transaction history of account: [" + acc + "]" + "\n\n" + acc.getTransactions());                       
                        }                                               
                        } else {
                        System.out.println("\n\u001B[31m" + "Sorry! " + client + " does not have an account yet." + "\u001B[0m" + "\n");
                        }
                        } else {
                        System.out.println("\n\u001B[31m" + "Sorry! We don't have any clients yet." + "\u001B[0m" + "\n");
                        }
                        return true;
    }
}
