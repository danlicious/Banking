package banking;

import static banking.Bank.getClientList;
import java.util.Set;

public class Banking {

    public static void main(String[] args) {

        System.out.println("\n\033[46m" + "       { Welcome to BBM \"Big Brains, Big Money\" }        " + "\033[0m");

        Bank bank = new Bank();
        int userOption;
        Client client;
        Account account;

        do {

            userOption = UserInputManager.retrieveUserOption();

            if (userOption == 1) {                          //CREATE CLIENT
                client = UserInputManager.retrieveClientInfo();
                bank.addClient(client);
                System.out.println("\n\u001B[32mTask completed succesfully!\u001B[0m");

            } else if (userOption == 2) {                 //CREATE ACCOUNT 

                if (Bank.getClientList().size() > 0) {
                    try {
                        client = bank.getClient(UserInputManager.retrieveClientId());
                        account = UserInputManager.retrieveAccountType(client);

                        if (account == null) {
                            System.out.println("\u001B[31m" + "Sorry! that wasn't an option." + "\u001B[0m" + "\n");
                        } else {
                            client.addAccount(account);
                            System.out.println("\n\u001B[32mTask completed succesfully!\u001B[0m");
                        }

                    } catch (Exception e) {
                        System.out.println("\u001B[31m" + "Sorry! this client does not exist." + "\u001B[0m" + "\n");
                    }

                } else {
                    System.out.println("\u001B[31m" + "Sorry! We don't have any clients yet." + "\u001B[0m" + "\n");
                }

            } else if (userOption == 3 || userOption == 4) {    //DEPOSIT/WITHDRAWAL

                if (getClientList().size() > 0) {

                    try {

                        client = bank.getClient(UserInputManager.retrieveClientId());

                        if (client.getAccountList().size() > 0) {

                            try {
                                bank.displayClientAccounts(client.getId());
                                account = client.getAccount(UserInputManager.retrieveAccountNumber());
                                double amount = UserInputManager.retrieveTransactionAmount();
                                
                                if (userOption == 3) {
                                    account.deposit(amount);
                                    
                                  
                                }
                                if (userOption == 4) {  
                                    account.withdrawal(amount);
                                    
                                    
                                }
                                System.out.println("\nYour new balance for this account is: " + account);
                                System.out.println("\n\u001B[32mTask completed succesfully!\u001B[0m");

                            } catch (Exception e) {
                                System.out.println("\u001B[31m" + "Sorry! this account does not belong to " + client + "." + "\u001B[0m" + "\n");
                            }

                        } else {
                            System.out.println("\u001B[31m" + "Sorry! " + client + " does not have an account yet." + "\u001B[0m" + "\n");
                        }

                    } catch (Exception e) {
                        System.out.println("\u001B[31m" + "Sorry! This client does not exist." + "\u001B[0m" + "\n");
                    }

                } else {
                    System.out.println("\u001B[31m" + "Sorry! We don't have any clients yet." + "\u001B[0m" + "\n");
                }
            } else if (userOption == 5) {
                
                bank.listAccountTransactions();
                System.out.println("\n\u001B[32mTask completed succesfully!\u001B[0m");
            } else if (userOption == 6) {

                bank.displayClientList();
                System.out.println("\n\u001B[32mTask completed succesfully!\u001B[0m");
            } else if (userOption == 7) {
                if (getClientList().size() > 0) {
                    try {
                        bank.displayClientAccounts(UserInputManager.retrieveClientId());
                        System.out.println("\n\u001B[32mTask completed succesfully!\u001B[0m");
                    } catch (Exception e) {
                        System.out.println("\u001B[31m" + "Sorry! This client does not exist." + "\u001B[0m" + "\n");
                    }
                } else {
                    System.out.println("\u001B[31m" + "Sorry! We don't have any clients yet." + "\u001B[0m" + "\n");
                }

            } else {
                System.out.println("\u001B[31m" + "Your input must correspond to one of the options [1,7]" + "\u001B[0m" + "\n");
            }

        } while (!(userOption == 0));
        System.out.println("\n(TESTING) Input was " + userOption + ", stopping program.");
    }
}
