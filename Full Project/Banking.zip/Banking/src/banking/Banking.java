package banking;
public class Banking {
    public static void main(String[] args) {
       
    }
}
