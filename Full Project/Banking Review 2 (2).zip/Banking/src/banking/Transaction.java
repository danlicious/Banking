package banking;


public class Transaction implements ITransaction{  //Marius
  
   private String type;
   private double amount;

   //@RR
    public Transaction(String type, double amount) {  //Marius
        this.type = type;
        this.amount = amount;
    }
   
   @Override
    public String toString(){  //Marius
       
      String TransText = type + " of " + amount + "$";  
      return TransText;
    }

    public String getType() {  //Marius
        return type;
    }

    public void setType(String type) {  //Marius
        this.type = type;
    }

    public double getAmount() {  //Marius
        return amount;
    }

    public void setAmount(double amount) {  //Marius
        this.amount = amount;
    }
    
}
