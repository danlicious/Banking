package banking;

public class CheckingAccount extends Account{

    public CheckingAccount(Client owner, String type) {
        super(owner, type);
    }

}
