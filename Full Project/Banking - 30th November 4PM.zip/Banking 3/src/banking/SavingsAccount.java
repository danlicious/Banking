package banking;

public class SavingsAccount extends Account{  //Marius

    public SavingsAccount() {  //Marius
        super("Savings");
    }
   
}
