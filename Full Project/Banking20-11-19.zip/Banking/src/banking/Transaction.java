package banking;


public class Transaction implements ITransaction{
  
   private String transactionType;
   private double amount;
   
   @Override
    public String toString(){
       
       System.out.println("");  
       return null;
    }
}
