package banking;

public class SavingsAccount extends Account{

    public SavingsAccount() {
        super("Savings");
    }
   
}
