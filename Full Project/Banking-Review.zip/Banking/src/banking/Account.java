package banking;

import java.util.ArrayList;


public class Account{
    
    private static int counter = 0;   
    private int accountNumber;
    protected Client owner;
    protected String type; 
    protected double balance;
    protected ArrayList<Transaction> transactions;
    
  
    
    public Account(String type) {
        this.accountNumber = counter+1;
        this.owner = null;
        this.type = type;
        this.balance = 0;
        counter++;
    }
    
    
    public int getAccountNumber() {
        return accountNumber;
    }
    
    public void setAccountNumber(int accountNumber) {
        this.accountNumber = accountNumber;
    }

    public static int getCounter() {
        return counter;
    }

    public void setCounter(int counter) {
        this.counter = counter;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public Client getOwner() {
        return owner;
    }

    public void setOwner(Client owner) {
        this.owner = owner;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
    
    
    double deposit(double d){
    
        this.balance = this.balance+d;
      
        // Create the corresponding Transaction object and add it to the transactions list
        //TODO
        return this.balance;
           
    }
    public void displayAllTransactions(){
      
        for (Transaction transaction : transactions) {
            System.out.println(transaction);
        }
    }
    public ArrayList<Transaction> getTransactions(){
        //TODO
      return null;
                     
    }
        
   @Override
    public String toString(){ //Marius
      
     
      String accountInfo = type + "(" + accountNumber + "): " + balance + "$";  
      return accountInfo;
         
    }
    
    public double withdrawal(double w){
          
       this.balance = this.balance - w;
       
     
     // Create the corresponding Transaction element and add it to the transactions list
      //TODO
     return this.balance;
     
    
    }
}

