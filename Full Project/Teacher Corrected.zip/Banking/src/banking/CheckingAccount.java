package banking;

public class CheckingAccount extends Account{

    public CheckingAccount(Client owner, String type) { //Marius
        super(owner, type);
    }

    public CheckingAccount() {
        super("Checking");
    }

}
