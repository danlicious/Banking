package banking;

public class SavingsAccount extends Account{

    public SavingsAccount(Client owner, String type) { //Marius
        super(owner, type);
    }

    public SavingsAccount() {
        super("Savings");
    }
    
    
   
}
