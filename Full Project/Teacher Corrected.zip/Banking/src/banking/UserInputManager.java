package banking;

import java.util.Scanner;

//@RR
public class UserInputManager implements IUserInputManager{

    private static boolean valid; //Is the input usable by the calling method?
    private static int inputLength;
    private static int counter; //used for counting
    private static String userInput;
    private static String validInput; //Final and (if needed) transformed input.
    private static String sample;   //used for substrings.
    private static final Scanner scan = new Scanner(System.in);

    public int retrieveAccountNumber() { //Marius

        Account acc = new Account();
        System.out.print("\nPlease enter the account number of the desired account: ");
        int accountNum = scan.nextInt();
        if (accountNum < 1) {
            System.out.println("\u001B[31m" + "This account number is invalid, please try again" + "\u001B[0m");
            retrieveAccountNumber();
        } else if (accountNum > acc.getCounter()) {
            System.out.println("\u001B[31m" + "This account number is invalid, please try again" + "\u001B[0m");
            retrieveAccountNumber();
        }
        return accountNum ;
    }

    @Override
    public Account retrieveAccountType() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public Account retrieveAccountType(Client owner) {

        String type1 = "[1] Checking";
        String type2 = "[2] Savings";
        System.out.println("\nPlease enter the desired type of account.");
        System.out.println("=========================================================");
        System.out.printf("%n%-32s%-32s%n%n=========================================================%nSelection: ", type1, type2);

        int accountType = scan.nextInt();

        Account account = null;

        if(accountType ==1 ){
            account = new CheckingAccount(owner, "Checking");
        }else if(accountType ==2){
            account = new CheckingAccount(owner, "Savings");
        }else{
                account = null; 
        }
        return account;
    }

    //Farhan
    public int retrieveClientId() {

        System.out.print("\nPlease enter the client's id: ");
        int id = scan.nextInt();
        return id;

    }

    //Farhan
    public Client retrieveClientInfo() {

        Client client = new Client();
        while(scan.nextLine().isEmpty()){
        System.out.print("\nWhat is the client's first name? ");
        String fn = scan.nextLine();  
        String fnoutput = fn.substring(0, 1).toUpperCase() + fn.substring(1);
        client.setFirstName(fnoutput);
        System.out.print("What is the client's last name? ");
        String ln = scan.nextLine();
        String lnoutput = ln.substring(0, 1).toUpperCase() + ln.substring(1);
        client.setLastName(lnoutput);
        break;
        }
        
        return client;
    }

    public double retrieveTransactionAmount() {
        System.out.print("Please enter the desired amount for the current transaction: ");
        double amount = scan.nextDouble();
        return amount;
    }

    //Farhan, Daniel, Marius
    public int retrieveUserOption() { //Marius
        String option1 = "[1] Add a new Client";
        String option2 = "[2] Create a new Account";
        String option3 = "[3] Make a Deposit";
        String option4 = "[4] Make a Withdrawal";
        String option5 = "[5] List Account Transactions";
        String option6 = "[6] List Clients";
        String option7 = "[7] List Client Accounts";
        System.out.println("\nTo perform an action, enter its corresponding number.");
        System.out.println("=========================================================");
        System.out.printf("%n%-32s%-32s%n%-32s%-32s%n%-32s%-32s%n%-32s%n%n=========================================================%nSelection: ", option1, option2, option3, option4, option5, option6, option7);
        int userOption = scan.nextInt();
        return userOption;
    }

}
