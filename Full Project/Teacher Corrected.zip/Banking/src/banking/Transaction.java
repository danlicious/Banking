package banking;

import java.text.DecimalFormat;

public class Transaction implements ITransaction{
  
   private String type;
   private double amount;
   private static DecimalFormat df = new DecimalFormat("#,###,##0.00"); //Marius
   
   public Transaction(String type, double amount) {  //Marius
        this.type = type;
        this.amount = amount;
   }

    public String getType() { //Marius
        return type;
    }

    public void setType(String type) { //Marius
        this.type = type;
    }

    public double getAmount() { //Marius
        return amount;
    }

    public void setAmount(double amount) { //Marius
        this.amount = amount;
    }
   
   @Override
    public String toString(){ //Marius
       
      String TransText = "\u001B[34m" + type + " of " + this.df.format(this.amount) + "$\u001B[0m";  
      return TransText;
    }
    
}
