package banking;
/*1 

December 2019

Daniel Petrushin 1967277
Marius Axente 1972099
Farhan Shoaib

*/
import static banking.Bank.getClientList;
import java.util.Set;

public class Banking {

    public static void main(String[] args) {

        System.out.println("\n\033[46m" + "       { Welcome to BBM \"Big Brains, Big Money\" }        " + "\033[0m");  //Marius

        Bank bank = new Bank();
        int userOption;
        Client client = null;
        Account account = null;
        UserInputManager uim = new UserInputManager();
        
        Test.test(bank);

        do {

            userOption = uim.retrieveUserOption();

            if (userOption == 1) {                          //CREATE CLIENT
                client = uim.retrieveClientInfo();
                bank.addClient(client);
                System.out.println("\n\u001B[32mTask completed succesfully!\u001B[0m"); //Marius

            } else if (userOption == 2) {                 //CREATE ACCOUNT 

                if (Bank.getClientList().size() > 0) {
                    try {
                        client = bank.getClient(uim.retrieveClientId());
                        account = uim.retrieveAccountType(client);

                        if (account == null) {
                            System.out.println("\n\u001B[31m" + "Sorry! that wasn't an option." + "\u001B[0m");
                        } else {
                            client.addAccount(account);
                            System.out.println("\n\u001B[32mTask completed succesfully!\u001B[0m"); //Marius
                        }

                    } catch (Exception e) {
                        System.out.println("\n\u001B[31m" + "Sorry! this client does not exist." + "\u001B[0m");
                    }

                } else {
                    System.out.println("\n\u001B[31m" + "Sorry! We don't have any clients yet." + "\u001B[0m");
                }

            } else if (userOption == 3 || userOption == 4) {    //DEPOSIT/WITHDRAWAL

                if (getClientList().size() > 0) {

                    try {
                        int clientId = uim.retrieveClientId();
                        client = bank.getClient(clientId);
                        
                        if (client.getAccountList().size() > 0) {
                            try {
                            account = bank.getClientAccount(clientId, uim.retrieveAccountNumber());
                                bank.displayClientAccounts(client.getId());
                               
                                double amount = uim.retrieveTransactionAmount();

                                if (userOption == 3) {
                                    account.deposit(amount);

                                }
                                if (userOption == 4) {
                                    account.withdrawal(amount);

                                }
                                System.out.println("\nYour new balance for this account is: " + account); //Marius
                                System.out.println("\n\u001B[32mTask completed succesfully!\u001B[0m"); //Marius

                            } catch (Exception e) {
                                System.out.println("\n\u001B[31m" + "Sorry! this account does not belong to " + client + "." + "\u001B[0m");
                            }

                        } else {
                            System.out.println("\n\u001B[31m" + "Sorry! " + client + " does not have an account yet." + "\u001B[0m");
                        }

                    } catch (Exception e) {
                        System.out.println("\n\u001B[31m" + "Sorry! This client does not exist." + "\u001B[0m");
                    }

                } else {
                    System.out.println("\n\u001B[31m" + "Sorry! We don't have any clients yet." + "\u001B[0m");
                }
            } else if (userOption == 5) {

                if (getClientList().size() > 0) {

                    try {
                        int clientId = uim.retrieveClientId();
                        client = bank.getClient(clientId);
                        
                        if (client.getAccountList().size() > 0) {
                            try {
                            account = bank.getClientAccount(clientId, uim.retrieveAccountNumber());
                            account.displayAllTransactions();
                            } catch (Exception e) {
                                System.out.println("\n\u001B[31m" + "Sorry! this account does not belong to " + client + "." + "\u001B[0m");
                            }
                        } else {
                            System.out.println("\n\u001B[31m" + "Sorry! this client does not have an account yet." + "\u001B[0m");
                        }

                    } catch (Exception e) {
                        System.out.println("\n\u001B[31m" + "Sorry! This client does not exist." + "\u001B[0m");
                    }

                } else {
                    System.out.println("\n\u001B[31m" + "Sorry! We don't have any clients yet." + "\u001B[0m");
                }

            } else if (userOption == 6) {

                bank.displayClientList();
                System.out.println("\n\u001B[32mTask completed succesfully!\u001B[0m"); //Marius
            } else if (userOption == 7) {
                if (getClientList().size() > 0) {
                    try {
                        bank.displayClientAccounts(uim.retrieveClientId());
                        System.out.println("\n\u001B[32mTask completed succesfully!\u001B[0m"); //Marius
                    } catch (Exception e) {
                        System.out.println("\n\u001B[31m" + "Sorry! This client does not exist." + "\u001B[0m");
                    }
                } else {
                    System.out.println("\n\u001B[31m" + "Sorry! We don't have any clients yet." + "\u001B[0m");
                }

            } else {
                System.out.println("\n\u001B[31m" + "Your input must correspond to one of the options [1,7]" + "\u001B[0m");
            }

        } while (!(userOption
                == 0));
        System.out.println(
                "\n(TESTING) Input was " + userOption + ", stopping program.");
    }
}
