package banking;

import java.text.DecimalFormat;
import java.util.ArrayList;

//@RR
public class Account implements IAccount{  //Marius

    protected static int counter = 1;
    protected int accountNumber;
    protected Client owner;
    protected String type;
    protected double balance;
    protected ArrayList<Transaction> transactions;
    protected static DecimalFormat df = new DecimalFormat("#,###,##0.00");

    public Account() {
    }

    //@RR
    public Account(String type) {
        this.type = type;
        this.transactions = new ArrayList<>();
        this.accountNumber = counter;
        this.owner = null;
        this.balance = 0;
        counter++;
    }
    
    
    public Account(Client owner, String type) { //Marius
        this.transactions = new ArrayList<>();
        this.accountNumber = counter;
        this.owner = owner;
        this.type = type;
        this.balance = 0;
        counter++;
    }

    public double deposit(double d) {//Daniel //Farhan //Marius

        Transaction transaction = new Transaction("Deposit", d);
        transactions.add(transaction);
        this.balance = this.balance + d;
        return this.balance;        
    }

    public void displayAllTransactions() {//Daniel //Farhan //Marius
        
        for (int i = 0; i < transactions.size(); i++) {
            System.out.println(transactions.get(i).toString());
        }
        System.out.println(this);
    }

    @Override
    public String toString() { //Marius

        String accountInfo = "\u001B[34m" + this.type + "(" + this.accountNumber + "): " + this.df.format(this.balance) + "$" + "\u001B[0m";
        return accountInfo;

    }

    public double withdrawal(double w) {//Daniel //Farhan //Marius

        Transaction transaction = new Transaction("Withdrawal", w);              
        this.transactions.add(transaction);
        this.balance = this.balance - w;
        return this.balance;

    }

    public int getAccountNumber() { //Marius
        return accountNumber;
    }

    public void setAccountNumber(int accountNumber) { //Marius
        this.accountNumber = accountNumber;
    }

    public int getCounter() { //Marius
        return counter;
    }

    public void setCounter(int counter) { //Marius
        this.counter = counter;
    }

    public double getBalance() { //Marius
        return balance;
    }

    public void setBalance(double balance) { //Marius
        this.balance = balance;
    }

    public Client getOwner() { //Marius
        return owner;
    }

    public void setOwner(Client owner) { //Marius
        this.owner = owner;
    }

    public String getType() { //Marius
        return type;
    }

    public void setType(String type) { //Marius
        this.type = type;
    }

    public ArrayList<Transaction> getTransactions() { //Marius
        return this.transactions;

    }

    public void setTransactions(ArrayList<Transaction> transactions) { //Marius
        this.transactions = transactions;
    }

}
