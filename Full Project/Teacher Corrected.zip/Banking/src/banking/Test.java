/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package banking;


/**
 *
 * @author cstuser
 */
public class Test {
    public static Account formalTestAccountC;
    public static Account formalTestAccountS;

    public static void test(Bank myBank) {
        GenerateClients(myBank);
        CreateSavingsAccounts(myBank);
        CreateCheckingAccounts(myBank);
        CreateTransactions(myBank);
        


    }
        
    private static void GenerateClients(Bank myBank){
        Client testClient = new Client("Ronald", "Raphael");
        myBank.addClient(testClient);
        testClient = new Client("Dany", "Raphael");
        myBank.addClient(testClient);
        testClient = new Client("Joe", "Smith");
        myBank.addClient(testClient);
        testClient = new Client("Jane", "Doe");
        myBank.addClient(testClient);
    }

    private static void CreateSavingsAccounts(Bank myBank){
        SavingsAccount testAccount = new SavingsAccount();
        myBank.getClient(1).addAccount(testAccount);
        
        testAccount = new SavingsAccount();
        myBank.getClient(2).addAccount(testAccount);

        testAccount = new SavingsAccount();
        myBank.getClient(2).addAccount(testAccount);
        
        testAccount = new SavingsAccount();
        myBank.getClient(3).addAccount(testAccount);
        formalTestAccountS = testAccount;

        testAccount = new SavingsAccount();
        myBank.getClient(4).addAccount(testAccount);
    }
    
    private static void CreateCheckingAccounts(Bank myBank){
        CheckingAccount testAccount = new CheckingAccount();
        myBank.getClient(1).addAccount(testAccount);

        testAccount = new CheckingAccount();
        myBank.getClient(2).addAccount(testAccount);
        formalTestAccountC  = testAccount;
        
        testAccount = new CheckingAccount();
        myBank.getClient(2).addAccount(testAccount);
        
        testAccount = new CheckingAccount();
        myBank.getClient(4).addAccount(testAccount);
    }
    
    private static void CreateTransactions(Bank myBank){
        Account testAccount = myBank.getClientAccount(1, 1);
        testAccount.deposit(500);
        testAccount = myBank.getClientAccount(1, 6);
        testAccount.deposit(1500);
        testAccount.withdrawal(250);

        testAccount = myBank.getClientAccount(2, 2);
        testAccount.deposit(1125.45);
        testAccount.deposit(85.15);
        testAccount = myBank.getClientAccount(2, 3);
        testAccount.deposit(85.15);
        testAccount = myBank.getClientAccount(2, 7);
        testAccount.deposit(11.45);
        testAccount.withdrawal(85.15);
        testAccount = myBank.getClientAccount(2, 8);
        testAccount.withdrawal(12.45);
        testAccount.deposit(85.15);
        testAccount.withdrawal(13.45);
        testAccount.deposit(85.15);
        testAccount.withdrawal(14.45);
        testAccount.deposit(85.15);

        testAccount = myBank.getClientAccount(3, 4);
        testAccount.deposit(125.45);
        testAccount.withdrawal(13.45);
        testAccount.deposit(85.15);
 
        testAccount = myBank.getClientAccount(4, 5);
        testAccount.deposit(78);
        testAccount.deposit(87);
        testAccount.deposit(2050);
        testAccount.withdrawal(250);

        testAccount = myBank.getClientAccount(4, 9);
        testAccount.deposit(178);
        testAccount.deposit(873);
        testAccount.deposit(2050);
        testAccount.withdrawal(250);
    }


}
