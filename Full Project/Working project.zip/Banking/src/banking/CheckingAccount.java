package banking;

public class CheckingAccount extends Account{ //Marius

    public CheckingAccount() {  //Marius
        super("Checking");
    }

}
