package banking;

import java.text.DecimalFormat;


public class Transaction implements ITransaction{  //Marius
  
   private String type;
   private double amount;
   DecimalFormat df = new DecimalFormat("#,###,##0.00");
   
    //@RR
    public Transaction(String type, double amount) {  //Marius
        this.type = type;
        this.amount = amount;
    }      

    public String getType() {  //Marius
        return this.type;
    }

    public void setType(String type) {  //Marius
        this.type = type;
    }

    public double getAmount() {  //Marius
        return this.amount;
    }

    public void setAmount(double amount) {  //Marius
        this.amount = amount;
    }
    
    public String displayAmountCorrectly(){ //Marius: this gives us the amount in the form of 0.00$ rather than 0.0$
        return df.format(this.amount);
    }
    @Override
    public String toString(){  //Marius
       
      String TransText = "\u001B[34m" + this.type + " of " + this.displayAmountCorrectly() + "$" + "\u001B[0m";  
      return TransText;
    }
}
