package banking;

import java.util.ArrayList;

public class Bank implements IBank {

    //Daniel - I put conditions to protect 0the bank properties
    private static final String bankNumber = "123456789";
    private static final String address = "821 Sainte Croix Ave";
    private static ArrayList<Client> clientList = new ArrayList<>();
    

    public boolean createClient() {

        System.out.println("\n\u001B[32m" + "(DEVELOPMENT) Creating a new Client..." + "\u001B[0m");
        Client newClient = UserInputManager.retrieveClientInfo();
        addClient(newClient);
        return true;

    }

    public boolean createAccount() {

        if (getClientList().size() > 0) {
            System.out.println("\n\u001B[32m" + "(DEVELOPMENT) Creating a new Account..." + "\u001B[0m");
            Client client = getClient(UserInputManager.retrieveClientId());
            System.out.println("\n\u001B[32m" + "(DEVELOPMENT) Client: " + "\u001B[0m" + client.toString());
            Account account = UserInputManager.retrieveAccountType(client);
            client.addAccount(account);

        } else {
            System.out.println("\n\u001B[31m" + "Sorry! We don't have any clients yet." + "\u001B[0m" +  "\n");
        }
        return true;
    }

    public boolean createTransaction(String type) { //Daniel  //Marius

        if (getClientList().size() > 0) {
            Client client = getClient(UserInputManager.retrieveClientId());
            if (client.getAccountList().size() > 0) {
                            
                        client.displayAccounts();                      
                        int accNum = UserInputManager.retrieveAccountNumber();
                        Account acc = client.getAccount(accNum);
                        
                        if(acc == null){
                            System.out.println("\n\u001B[31m" + "This account number does not belong to this user, restarting function..." + "\u001B[0m");
                            createTransaction(type);
                        }else{
                            double accBalance = acc.getBalance();
                            System.out.println("Your balance is " + acc.displayBalanceCorrectly() + "$\n");
                            double amount = UserInputManager.retrieveTransactionAmount();
                            Transaction t = new Transaction(type, amount);
                            System.out.println("Transaction: " + t + "\n");
                            switch (type) {                                                         
                                case "deposit":                                      
                                        
                                    acc.setBalance(acc.getBalance() + amount);
                                    
                                    break;

                                case "withdrawal":

                                    acc.setBalance(acc.getBalance() - amount);

                                    break;

                            }
                            
                            acc.getTransactions().add(t);
                            System.out.println("Your new balance for this account is: \n" + acc);
                            
                        }
                                                                        
            } else {
                System.out.println("\n\u001B[31m" + "Sorry! " + client + " does not have an account yet." + "\u001B[0m" + "\n");
            }
        } else {
            System.out.println("\n\u001B[31m" + "Sorry! We don't have any clients yet." + "\u001B[0m" + "\n");
        }
        return false;
    }

    public boolean listAccountTransactions() {//Daniel  //Marius

        if (getClientList().size() > 0) {
            Client client = getClient(UserInputManager.retrieveClientId());
            if (client.getAccountList().size() > 0) {
                System.out.println("\n\u001B[32m" + "(DEVELOPMENT) Account ID needed for listing." + "\u001B[0m" );
                        client.displayAccounts();                      
                        int accNum = UserInputManager.retrieveAccountNumber();
                        Account acc = client.getAccount(accNum);
                        
                        if(acc == null){
                            listAccountTransactions();
                        }else{                        
                        System.out.println("\n\u001B[32m" + "Displaying transaction history of account: [" + acc + "]" + "\u001B[0m" + "\n" + acc.getTransactions());                       
                        }
                
                //output transactions in this form: -transactionType of transactionAmount
                // and this form: accountType(accountNum): balance
                
                
            } else {
                System.out.println("\n\u001B[31m" + "Sorry! " + client + " does not have an account yet." + "\u001B[0m" + "\n");
            }
        } else {
            System.out.println("\n\u001B[31m" + "Sorry! We don't have any clients yet." + "\u001B[0m" + "\n");
        }
        return true;

    }

    @Override //Farhan
    public void addClient(Client newClient) {

        clientList.add(newClient.getId() - 1, newClient);
        System.out.println("\n\u001B[32m" + "(DEVELOPMENT) Added client " + "\u001B[0m" + clientList.toString());

    }

    @Override
    public void displayClientAccounts(int clientId) {
         if (getClientList().size() > 0) {
            Client client = getClient(clientId);
            client.displayAccounts();
        } else {
            System.out.println("\n\u001B[31m" + "Sorry! We don't have any clients yet." + "\u001B[0m" + "\n");
        }
    
    }

    @Override //Daniel
    public void displayClientList() {

        System.out.println("\nList of current clients:");
        for (int i = 0; i < clientList.size(); i++) {
            System.out.println(clientList.get(i).toString());
        }

    }

    @Override//Daniel
    public Client getClient(int id) {
        return clientList.get(id - 1);
    }

    @Override
    public Account getClientAccount(int clientId, int accountNumber) {
        Client c = this.getClient(clientId);
        if(c != null){
            return c.getAccount(accountNumber);
        }
        return null;
    }

    public static String getBankNumber() {
        return bankNumber;
    }

    public static String getAddress() {
        return address;
    }

    public static ArrayList<Client> getClientList() {
        return clientList;
    }

    public static void setClientList(ArrayList<Client> clientList) {
        Bank.clientList = clientList;
    }

}
