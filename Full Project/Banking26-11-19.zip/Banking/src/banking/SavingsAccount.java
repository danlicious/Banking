package banking;

public class SavingsAccount extends Account{

    public SavingsAccount(Client owner, String type) {
        super(owner, type);
    }
   
}
